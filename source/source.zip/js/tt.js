var imgload  = chrome.extension.getURL('8-0.gif')
var rutalogo = chrome.extension.getURL('candado.png')
var img1 = new Image()
var img2 = new Image()
img1.src = imgload
img2.src = rutalogo